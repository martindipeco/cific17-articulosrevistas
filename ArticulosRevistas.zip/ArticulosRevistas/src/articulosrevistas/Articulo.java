/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package articulosrevistas;

import java.util.ArrayList;

/**
 *
 * @author admin
 */
public class Articulo {
    
    private String titulo;
    private String periodista;
    private int contPalabras;
    private String texto;
    private long idArticulo;
    private ArrayList<String> Temas = new ArrayList<String>();
    public Articulo(String titulo, String periodista, int contPalabras, String texto, long idArticulo) {
    this.titulo = titulo;
    this.periodista = periodista;
    this.contPalabras = contPalabras;
    this.texto = texto;
    this.idArticulo = idArticulo;
    this.Temas = new ArrayList<String>();
    }
    public boolean addTemas(String tema) {
    return Temas.add(tema);
    }
    public boolean contieneTema(String tema) {
    return Temas.contains(tema);
    }
    public String getTema(int posicion) {
    return Temas.get(posicion);
    }
    public void setTema(int posicion, String tema) {
    Temas.set(posicion, tema);
    }
    // Getters y setters para las propiedades de la clase Articulo
    public String getTitulo() {
    return titulo;
    }
    public void setTitulo(String titulo) {
    this.titulo = titulo;
    }
    public String getPeriodista() {
    return periodista;
    }

    public void setPeriodista(String periodista) {
    this.periodista = periodista;
    }
    public int getContPalabras() {
    return contPalabras;
    }
    public void setContPalabras(int contPalabras) {
    this.contPalabras = contPalabras;
    }
    public String getTexto() {
    return texto;
    }
    public void setTexto(String texto) {
    this.texto = texto;
    }
    public long getIdArticulo() {
    return idArticulo;
    }
    public void setIdArticulo(long idArticulo) {
    this.idArticulo = idArticulo;
    }
    
}
