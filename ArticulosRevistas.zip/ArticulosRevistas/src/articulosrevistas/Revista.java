/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package articulosrevistas;

import java.util.ArrayList;

/**
 *
 * @author admin
 */
public class Revista {
    
    private String titulo;
    private int ejemplar;
    //El ArrayList de elementos ahora se declara como atributo de la clase
    private ArrayList<Articulo> elementos = new ArrayList<Articulo>();
    //La inicialización local de ArrayList<Articulo> elementos en el constructor no es necesaria.
    public Revista(int ejemplar, String titulo) {
    this.titulo = titulo;
    this.ejemplar = ejemplar;
    }
    //El método addElemento(Articulo articulo) se utiliza para agregar un objeto de la clase Articulo a la lista elementos. El
    //Parámetro de entrada de tipo Articulo llamado articulo representa el objeto de la clase Articulo que se desea agregar a
    //la lista elementos. El método add, elementos.add(articulo): de la clase ArrayList se utiliza para agregar un elemento a la
    //lista. Se agrega el objeto articulo pasado como parámetro a la lista elementos.
    public boolean addElemento(Articulo articulo) {
    return elementos.add(articulo);
    }

    public Articulo getArticuloEnPosicion(int posicion) {
    if (posicion >= 0 && posicion < elementos.size()) {
    return elementos.get(posicion);
    } else {
    return null; // Manejar el caso cuando la posición está fuera de rango
    }
}
    public int getCantidadArticulosDeTema(String tema) {
    return contadorTema(tema);
}
    //verifica si el tema del artículo coincide (ignorando mayúsculas y minúsculas) con el tema proporcionado como
    //argumento del método.
    public int contadorTema(String tema) {
    int contador = 0;
    for (Articulo articulo : elementos) {
    if (articulo.getTema(contador).equalsIgnoreCase(tema)) {
    contador++;
        }
    }
    return contador;
    }
    
}
